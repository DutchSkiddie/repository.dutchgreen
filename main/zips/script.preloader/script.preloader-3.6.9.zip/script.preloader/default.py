from resources.lib import setup

if __name__ == '__main__':
    setup.init()
    exit()